TRUE GAIN — MEET THE COACH REFERENCE UPDATE

This update keeps the approved Coach photo framing and places the animated BSc card
at the bottom-right of the left Coach panel, beneath the visible body/arms, matching
the supplied screenshot.

Replace in GitHub:
- app/page.tsx
- app/globals.css
